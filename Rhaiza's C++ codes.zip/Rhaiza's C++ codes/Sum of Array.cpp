#include<iostream>
#include<windows.h>
using namespace std;
int main (){
int x;
int sum=0;
system("Color 4");
cout<<"Enter:";
cin>>x;
int numbers[x];
for(int i=0;i<x;++i){
    cout<<"Enter the num["<<i<<"]:";
    cin>>numbers[i];
    sum=sum+numbers[i];
}
system("Color 5");
 for(int j=0;j<x;j++)
 {
     cout<<numbers[j]<<"\t";
 }
 cout<<"sum"<<sum;
return 0;
}



