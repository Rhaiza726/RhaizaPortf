#include <iostream>
using namespace std;

int main() {
    const int rows = 3;
    const int cols = 5;

    char seats[rows][cols];
    int reservedCount = 0;
    const int totalSeats = rows * cols;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            seats[i][j] = 'O';
        }
    }

    while (true) {
        cout << "\nSeating Arrangement:\n  ";
        for (int i = 0; i < cols; i++) {
            cout << i + 1 << " ";
        }
        cout << endl;

        for (int i = 0; i < rows; i++) {
            cout << i + 1 << " ";
            for (int j = 0; j < cols; j++) {
                cout << seats[i][j] << " ";
            }
            cout << endl;
        }

        if (reservedCount == totalSeats) {
            cout << "\nAll seats are reserved! FInd another airplane\n";
            break;
        }

        char choice;
        cout << "\nDo you want to (R)eserve, (C)ancel, or (Q)uit? ";
        cin >> choice;

        if (choice != 'R' && choice != 'r' && choice != 'C' && choice != 'c' && choice != 'Q' && choice != 'q') {
            cout << "Invalid choice! Please enter 'R' to reserve, 'C' to cancel, or 'Q' to quit.\n";
            continue;
        }

        if (choice == 'Q' || choice == 'q') {
            break;
        }

        int row, col;
        cout << "Enter row number (1-3): ";
        cin >> row;
        cout << "Enter seat number (1-5): ";
        cin >> col;

        if (row >= 1 && row <= rows && col >= 1 && col <= cols) {
            int rowIndex = row - 1;
            int colIndex = col - 1;

            if (choice == 'R' || choice == 'r') {
                if (seats[rowIndex][colIndex] == 'X') {
                    cout << "Seat already reserved. Choose another seat.\n";
                } else {
                    seats[rowIndex][colIndex] = 'X';
                    reservedCount++;
                    cout << "Seat successfully reserved!\n";
                }
            } else if (choice == 'C' || choice == 'c') {
                if (seats[rowIndex][colIndex] == 'O') {
                    cout << "Seat is already available. Nothing to cancel.\n";
                } else {
                    seats[rowIndex][colIndex] = 'O';
                    reservedCount--;
                    cout << "Reservation canceled successfully!\n";
                }
            } else {
                cout << "Invalid choice!\n";
            }
        } else {
            cout << "Invalid seat selection. Try again.\n";
        }
    }

    cout << "\nFinal Seating Arrangement:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << seats[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
